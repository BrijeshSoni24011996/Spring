
public class A {

	public A(){
//		CHAINING constructor using this/super
		this("");
	}
	
	public A(String msg){
		
//		this();
	}
	
}
